<!DOCTYPE html>
<html>
<head>
	<title>Contact</title>
</head>
<body>

	<?php var_dump($getUsers); ?>

</body>
</html>