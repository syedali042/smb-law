<div>
	<?php var_dump($getUsers); ?>
</div>