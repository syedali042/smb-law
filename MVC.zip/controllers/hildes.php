<?php

class CL_HILDES
{
	public function __construct()
	{
		$this->model = new MD_MAINMODEL();
		$this->temp = new LB_TEMPLATE('header', 'footer');
	}

	public function index()
	{
		$this->temp->loadcontent('index');
		$data['getUsers'] = $this->model->getUsers();
		$this->temp->loadview($data);
	}

	public function abc()
	{
		$this->temp->loadcontent('about');
		$data['getUsers'] = $this->model->getUsers();
		$this->temp->loadview($data);
	}

	public function contact(){
		$this->temp->loadcontent('contact');
		$data['getUsers'] = $this->model->getUsers();
		$this->temp->loadview($data);
	}
	
}